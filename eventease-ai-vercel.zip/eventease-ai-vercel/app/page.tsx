'use client';

import React, { useState } from 'react';
import { PlanData } from '@/lib/fallback';
import { Sparkles, Calendar, DollarSign, Users, MapPin, CheckSquare, Palette, Download, ShieldCheck, HelpCircle } from 'lucide-react';

export default function Home() {
  const [eventType, setEventType] = useState('Wedding Celebration');
  const [guestCount, setGuestCount] = useState(150);
  const [budget, setBudget] = useState(300000);
  const [currency, setCurrency] = useState('₹');
  const [location, setLocation] = useState('Pune, Maharashtra');
  const [vibeTheme, setVibeTheme] = useState('Royal Heritage & Contemporary Elegance');
  const [specialRequests, setSpecialRequests] = useState('Live acoustic set, pure vegetarian multi-course tasting, zero plastic waste');
  const [apiKey, setApiKey] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState<PlanData | null>(null);
  const [activeTab, setActiveTab] = useState<'budget' | 'timeline' | 'vendors' | 'ideas'>('budget');

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          eventType,
          guestCount,
          budget,
          currency,
          location,
          vibeTheme,
          specialRequests,
          apiKey
        })
      });
      const data = await res.json();
      setPlan(data);
    } catch (err) {
      console.error(err);
      alert('Failed to generate event blueprint.');
    } finally {
      setLoading(false);
    }
  };

  const downloadJson = () => {
    if (!plan) return;
    const blob = new Blob([JSON.stringify(plan, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `eventease-${eventType.toLowerCase().replace(/\s+/g, '-')}.json`;
    a.click();
  };

  return (
    <main className="min-h-screen px-4 py-8 md:px-12 max-w-7xl mx-auto">
      {/* Header */}
      <header className="mb-10 text-center md:text-left flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-6 gap-4">
        <div>
          <div className="flex items-center gap-2 justify-center md:justify-start">
            <Sparkles className="w-8 h-8 text-amber-400" />
            <h1 className="text-3xl md:text-4xl font-extrabold bg-gradient-to-r from-amber-400 via-rose-400 to-indigo-400 bg-clip-text text-transparent">
              EVENTEASE AI
            </h1>
          </div>
          <p className="text-slate-400 text-sm mt-1">Autonomous GenAI Event Planning Assistant • Vercel Native</p>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="password"
            placeholder="Gemini API Key (Optional)"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-xs px-3 py-2 rounded-lg text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-400 w-56"
          />
        </div>
      </header>

      {/* Form Section */}
      <section className="bg-slate-900/90 border border-slate-800 p-6 rounded-2xl shadow-xl mb-10">
        <form onSubmit={handleGenerate} className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Event Archetype</label>
            <select
              value={eventType}
              onChange={(e) => setEventType(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 px-3 py-2.5 rounded-xl text-slate-100 focus:border-amber-400 focus:outline-none"
            >
              <option>Wedding Celebration</option>
              <option>Milestone Birthday</option>
              <option>Community Festival / Fundraiser</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Guest Capacity</label>
            <div className="relative">
              <Users className="w-4 h-4 text-slate-500 absolute left-3 top-3.5" />
              <input
                type="number"
                value={guestCount}
                onChange={(e) => setGuestCount(Number(e.target.value))}
                min={5}
                className="w-full bg-slate-950 border border-slate-700 pl-9 pr-3 py-2.5 rounded-xl text-slate-100 focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Budget & Currency</label>
            <div className="flex gap-2">
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-24 bg-slate-950 border border-slate-700 px-2 py-2.5 rounded-xl text-slate-100 focus:border-amber-400 focus:outline-none"
              >
                <option value="₹">₹ INR</option>
                <option value="$">$ USD</option>
                <option value="€">€ EUR</option>
                <option value="£">£ GBP</option>
              </select>
              <input
                type="number"
                value={budget}
                onChange={(e) => setBudget(Number(e.target.value))}
                step={1000}
                className="flex-1 bg-slate-950 border border-slate-700 px-3 py-2.5 rounded-xl text-slate-100 focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Venue / City Location</label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-slate-500 absolute left-3 top-3.5" />
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 pl-9 pr-3 py-2.5 rounded-xl text-slate-100 focus:border-amber-400 focus:outline-none"
              />
            </div>
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Vibe & Aesthetic Vision</label>
            <input
              type="text"
              value={vibeTheme}
              onChange={(e) => setVibeTheme(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 px-3 py-2.5 rounded-xl text-slate-100 focus:border-amber-400 focus:outline-none"
            />
          </div>

          <div className="md:col-span-3">
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Special Constraints / Requirements</label>
            <textarea
              rows={2}
              value={specialRequests}
              onChange={(e) => setSpecialRequests(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 px-3 py-2 rounded-xl text-slate-100 focus:border-amber-400 focus:outline-none"
              placeholder="e.g. Dietary constraints, live band, eco-friendly favors..."
            />
          </div>

          <div className="md:col-span-3">
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-600 hover:to-rose-600 font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-white disabled:opacity-50"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Synthesizing Event Blueprint...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  <span>Generate Event Blueprint</span>
                </>
              )}
            </button>
          </div>
        </form>
      </section>

      {/* Results View */}
      {plan && (
        <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 shadow-2xl">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-800 pb-6 gap-4">
            <div>
              <span className="text-xs uppercase font-bold tracking-widest text-amber-400">EVENTEASE Master Plan</span>
              <h2 className="text-2xl md:text-3xl font-extrabold text-white mt-1">{plan.event_title}</h2>
              <p className="text-slate-400 text-sm mt-1 max-w-3xl">{plan.summary}</p>
            </div>
            <button
              onClick={downloadJson}
              className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all border border-slate-700"
            >
              <Download className="w-4 h-4 text-amber-400" />
              Download JSON
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="flex border-b border-slate-800 mt-6 gap-6 overflow-x-auto">
            <button
              onClick={() => setActiveTab('budget')}
              className={`pb-3 font-semibold text-sm transition-all flex items-center gap-2 ${activeTab === 'budget' ? 'border-b-2 border-amber-400 text-amber-400' : 'text-slate-400 hover:text-slate-200'}`}
            >
              <DollarSign className="w-4 h-4" /> Budget Breakdown
            </button>
            <button
              onClick={() => setActiveTab('timeline')}
              className={`pb-3 font-semibold text-sm transition-all flex items-center gap-2 ${activeTab === 'timeline' ? 'border-b-2 border-amber-400 text-amber-400' : 'text-slate-400 hover:text-slate-200'}`}
            >
              <Calendar className="w-4 h-4" /> Timeline & Run-of-Show
            </button>
            <button
              onClick={() => setActiveTab('vendors')}
              className={`pb-3 font-semibold text-sm transition-all flex items-center gap-2 ${activeTab === 'vendors' ? 'border-b-2 border-amber-400 text-amber-400' : 'text-slate-400 hover:text-slate-200'}`}
            >
              <ShieldCheck className="w-4 h-4" /> Vendor Due-Diligence
            </button>
            <button
              onClick={() => setActiveTab('ideas')}
              className={`pb-3 font-semibold text-sm transition-all flex items-center gap-2 ${activeTab === 'ideas' ? 'border-b-2 border-amber-400 text-amber-400' : 'text-slate-400 hover:text-slate-200'}`}
            >
              <Palette className="w-4 h-4" /> Personalized Ideas & Decor
            </button>
          </div>

          {/* Tab 1: Budget */}
          {activeTab === 'budget' && (
            <div className="mt-8 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
                <div>
                  <span className="text-xs text-slate-500 uppercase font-semibold">Total Projected Investment</span>
                  <div className="text-2xl font-bold text-emerald-400">{currency} {budget.toLocaleString()}</div>
                </div>
                <div>
                  <span className="text-xs text-slate-500 uppercase font-semibold">Per-Guest Ratio</span>
                  <div className="text-2xl font-bold text-amber-400">{currency} {(budget / guestCount).toFixed(2)}</div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {plan.budget_breakdown.map((item, idx) => (
                  <div key={idx} className="bg-slate-950/60 p-4 rounded-xl border border-slate-800/80 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-semibold text-slate-200 text-sm">{item.category}</span>
                        <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-800 text-amber-400">{item.percentage}%</span>
                      </div>
                      <p className="text-xs text-slate-400">{item.notes}</p>
                    </div>
                    <div className="text-lg font-bold text-slate-100 mt-3">
                      {currency} {item.amount.toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 2: Timeline */}
          {activeTab === 'timeline' && (
            <div className="mt-8 space-y-6">
              {plan.milestone_timeline.map((phase, pIdx) => (
                <div key={pIdx} className="bg-slate-950/80 p-5 rounded-xl border border-slate-800">
                  <h3 className="font-bold text-base text-amber-400 flex items-center gap-2 mb-3">
                    <CheckSquare className="w-4 h-4 text-rose-400" />
                    {phase.phase}
                  </h3>
                  <ul className="space-y-2">
                    {phase.items.map((it, itIdx) => (
                      <li key={itIdx} className="text-sm text-slate-300 flex items-start gap-2">
                        <span className="text-amber-500 font-bold">•</span>
                        <span>{it}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {/* Tab 3: Vendors */}
          {activeTab === 'vendors' && (
            <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
              {plan.vendor_checklist.map((v, vIdx) => (
                <div key={vIdx} className="bg-slate-950 p-5 rounded-xl border border-slate-800">
                  <h4 className="font-bold text-base text-amber-300 border-b border-slate-800 pb-2 mb-3">
                    {v.vendor_type}
                  </h4>
                  <div className="space-y-4">
                    <div>
                      <h5 className="text-xs font-semibold uppercase text-slate-400 mb-1 flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Must-Have Verifications
                      </h5>
                      <ul className="text-xs text-slate-300 space-y-1 list-disc pl-4">
                        {v.must_have_items.map((m, mIdx) => (
                          <li key={mIdx}>{m}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h5 className="text-xs font-semibold uppercase text-slate-400 mb-1 flex items-center gap-1">
                        <HelpCircle className="w-3.5 h-3.5 text-rose-400" /> Key Questions to Ask
                      </h5>
                      <ul className="text-xs text-slate-300 space-y-1 italic pl-4 list-disc">
                        {v.vital_questions.map((q, qIdx) => (
                          <li key={qIdx}>"{q}"</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Tab 4: Ideas */}
          {activeTab === 'ideas' && (
            <div className="mt-8 space-y-6">
              <div className="bg-slate-950 p-5 rounded-xl border border-slate-800">
                <span className="text-xs uppercase font-semibold text-slate-500">Theme & Palette</span>
                <h4 className="text-lg font-bold text-slate-200 mt-1">{plan.theme_and_decor.theme_name}</h4>
                <div className="flex flex-wrap gap-2 mt-3">
                  {plan.theme_and_decor.color_palette.map((c, cIdx) => (
                    <span key={cIdx} className="px-3 py-1 bg-slate-800 border border-slate-700 text-xs font-medium rounded-full text-slate-200">
                      ● {c}
                    </span>
                  ))}
                </div>
                <div className="mt-4">
                  <span className="text-xs font-semibold uppercase text-slate-400">Decor Highlights:</span>
                  <ul className="text-sm text-slate-300 list-disc pl-5 mt-1 space-y-1">
                    {plan.theme_and_decor.decor_highlights.map((d, dIdx) => (
                      <li key={dIdx}>{d}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <h5 className="font-bold text-sm text-amber-400 mb-2">🍽️ Food & Beverage Ideas</h5>
                  <ul className="text-xs text-slate-300 space-y-1.5 list-disc pl-4">
                    {plan.personalized_ideas.food_and_beverage.map((f, idx) => (
                      <li key={idx}>{f}</li>
                    ))}
                  </ul>
                </div>
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <h5 className="font-bold text-sm text-rose-400 mb-2">🎯 Engagement Activities</h5>
                  <ul className="text-xs text-slate-300 space-y-1.5 list-disc pl-4">
                    {plan.personalized_ideas.guest_engagement_activities.map((a, idx) => (
                      <li key={idx}>{a}</li>
                    ))}
                  </ul>
                </div>
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                  <h5 className="font-bold text-sm text-indigo-400 mb-2">🎁 Keepsakes & Favors</h5>
                  <ul className="text-xs text-slate-300 space-y-1.5 list-disc pl-4">
                    {plan.personalized_ideas.takeaway_favors.map((fav, idx) => (
                      <li key={idx}>{fav}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </section>
      )}
    </main>
  );
}
