import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "EVENTEASE AI | Autonomous GenAI Event Planning Assistant",
  description: "Next-generation AI event orchestrator for Weddings, Birthdays, and Community Events with budget allocations, timelines, and vendor checklists.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-950 text-slate-100 antialiased">{children}</body>
    </html>
  );
}
