import { NextResponse } from "next/server";
import { getFallbackPlan } from "@/lib/fallback";

const SYSTEM_PROMPT = `You are EVENTEASE AI, an elite event planner, budget strategist, and creative director with 15+ years of experience across luxury weddings, milestone birthdays, and high-impact community gatherings.
Your task is to take event parameters and return a comprehensive, highly realistic Master Event Dossier in VALID JSON.

CRITICAL INSTRUCTIONS:
1. Output MUST be ONLY valid JSON adhering strictly to the schema provided. No markdown fences, no explanatory text.
2. Budget amounts must balance to the total budget and be realistic.
3. Timelines must be chronological with specific milestones.
4. Vendor checklists must have strict verification points and vital questions.

SCHEMA:
{
  "event_title": "string",
  "summary": "string",
  "theme_and_decor": {
    "theme_name": "string",
    "color_palette": ["string"],
    "decor_highlights": ["string"],
    "signature_features": ["string"]
  },
  "budget_breakdown": [
    {"category": "string", "amount": 0, "percentage": 0, "notes": "string"}
  ],
  "milestone_timeline": [
    {"phase": "string", "items": ["string"]}
  ],
  "vendor_checklist": [
    {
      "vendor_type": "string",
      "must_have_items": ["string"],
      "vital_questions": ["string"]
    }
  ],
  "personalized_ideas": {
    "food_and_beverage": ["string"],
    "guest_engagement_activities": ["string"],
    "takeaway_favors": ["string"]
  }
}`;

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { eventType, guestCount, budget, currency, vibeTheme, location, specialRequests, apiKey } = body;

    const keyToUse = apiKey || process.env.GEMINI_API_KEY;

    if (!keyToUse) {
      const fallback = getFallbackPlan(
        eventType || "Wedding Celebration",
        Number(guestCount) || 100,
        Number(budget) || 10000,
        currency || "$",
        vibeTheme || "Elegant Modern",
        location || "City Center",
        specialRequests || ""
      );
      return NextResponse.json(fallback);
    }

    const userPrompt = `Generate a Master Event Dossier via EVENTEASE AI:
- Event: ${eventType}
- Guests: ${guestCount}
- Budget: ${currency} ${budget}
- Aesthetic Vibe: ${vibeTheme}
- Location: ${location}
- Special Notes: ${specialRequests || "None"}
`;

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${keyToUse}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: userPrompt }] }],
          systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
          generationConfig: {
            responseMimeType: "application/json",
            temperature: 0.4
          }
        })
      }
    );

    if (!response.ok) {
      console.warn("Gemini API call failed with status:", response.status);
      const fallback = getFallbackPlan(eventType, Number(guestCount), Number(budget), currency, vibeTheme, location, specialRequests);
      return NextResponse.json(fallback);
    }

    const data = await response.json();
    const candidateText = data.candidates?.[0]?.content?.parts?.[0]?.text;
    if (candidateText) {
      const parsed = JSON.parse(candidateText.trim());
      return NextResponse.json(parsed);
    } else {
      const fallback = getFallbackPlan(eventType, Number(guestCount), Number(budget), currency, vibeTheme, location, specialRequests);
      return NextResponse.json(fallback);
    }
  } catch (err) {
    console.error("API error, executing fallback:", err);
    const fallback = getFallbackPlan("Celebration Event", 100, 10000, "$", "Classic Modern", "Grand Ballroom", "");
    return NextResponse.json(fallback);
  }
}
