# EVENTEASE AI - Next.js Event Planning Assistant for Vercel

An enterprise Next.js App Router project configured for 1-click deployment on **Vercel** with zero-configuration build failures. Built for the Virtual Prompt War challenge.

---

## 🌟 Key Features

| Requirement | EVENTEASE AI Implementation |
|---|---|
| **Event Archetypes** | Weddings, Milestone Birthdays, and Community Events/Fundraisers. |
| **Intelligent Budgets** | Itemized allocation breakdown, percentage quotas, per-attendee metrics, and contingency buffers. |
| **Milestone Timelines** | Phased roadmaps (Pre-planning, Sprint) & day-of run-of-show schedule. |
| **Vendor Due-Diligence** | Category checklists with must-have compliance items and interview questions. |
| **Personalized Concepts** | Custom aesthetic themes, color swatches, culinary highlights, engagement rituals, and favors. |
| **Export Dossier** | One-click JSON export of the complete Master Event Dossier. |

---

## 🚀 Deployment Instructions for Vercel

### Option 1: Vercel CLI (Quickest)
1. Unpack the ZIP:
   ```bash
   unzip eventease-ai-vercel.zip
   cd eventease-ai-vercel
   ```
2. Deploy directly:
   ```bash
   npx vercel
   ```
3. (Optional) Set environment variable:
   ```bash
   npx vercel env add GEMINI_API_KEY
   ```

### Option 2: Deploy via GitHub
1. Initialize repository and push to GitHub:
   ```bash
   git init
   git add .
   git commit -m "Deploy EVENTEASE AI to Vercel"
   git branch -M main
   git remote add origin <your-github-repo-url>
   git push -u origin main
   ```
2. Visit [vercel.com/new](https://vercel.com/new) and import your repository.
3. Under **Environment Variables**, add `GEMINI_API_KEY` (optional; fallback engine handles offline evaluation).
4. Click **Deploy**.
